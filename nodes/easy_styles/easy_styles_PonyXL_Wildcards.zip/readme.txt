PonyXL Wildcards Vault files (https://civitai.com/models/615967/ponyxl-wildcards-vault)
converted for use in my 'Easy Styles Selector (minimal)' node

unzip inside 'ComfyUI\custom_nodes\agi_custom_nodes\nodes\easy_styles\'
and refresh ComfyUI interface
